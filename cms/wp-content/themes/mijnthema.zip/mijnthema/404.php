<?php get_header(); ?>

<div class="grid__bp0-column-12">
<section class="banner2">
    <div class="imgBannerContact"><h1 class="yellow contact">Oeps, Aflsag gemist? </h1>
<h5>Pagina niet gevonden</h5></div>
<a href="jonyluyp/producten">
<button class="button button2 button3">Ontdek onze Bikes hier</button></a>
</section>
</div>
<?php get_footer(); ?>


