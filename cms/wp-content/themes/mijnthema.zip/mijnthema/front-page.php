
<?php get_header(); ?>
<div class="grid__bp0-column-12">
<section class="banner" >
<div class="grid__bp0-column-12">
    <div class="imgBanner"></div>
</div>
</section>
</div>


<div class="grid__bp0-column-12">
    <h1 class="yellow">Win een audi R8</h1>
    <div class="grid__bp0-column-6"><div>
<ul id="exampleSlider" class="slider">
    <li><img src="/jonyluyp/wp-content/uploads/slider/home/koppel.jpg" alt=""></li>
    <li><img src="/jonyluyp/wp-content/uploads/slider/home/man+hond.jpg" alt=""></li>
    <li><img src="/jonyluyp/wp-content/uploads/slider/home/gezin.jpg" alt=""></li>
    <li><img src="/jonyluyp/wp-content/uploads/slider/home//jongkoppel.jpg" alt=""></li>
</ul></div></div>

    <div class="grid__bp0-column-5"><div>
    <hr class="redBorder" noshade>
    <h3 class="bruin">Post je </br>gordel selfie!
    <hr class="redBorder" noshade></h3>

    <a href="/jonyluyp/promos/"><img src="<?php bloginfo('template_url'); ?>/assets/doemee.png" class="doemee"></a>
    <p>Doe mee aan onze gordelselfie en maak kans op een splinternieuwe audi R8.
    Het enige wat je hoeft te doen is een selfie nemen met je gordel om.
    Het gaat overveiligheid, wees allen creatief om zo veilig mogelijk achter het stuur te kruipen.</p>
    </div></br>
    </div>
</div>

<div class="grid__bp0-column-12" id="onsAanbod"><div>
  <h1 class="bruin">Audi</h1> 
  <h5 class="black">Ons nieuwe aanbod aan auto's</h5> 
  <section id="aanbod">
      <div class="grid__bp0-column-4"><a href="/jonyluyp/producten/auto-1/"><div id="auto1"></div></a></div>
      <div class="grid__bp0-column-4"><a href="/jonyluyp/producten/auto-2/"><div id="auto2"></div></a></div>
      <div class="grid__bp0-column-4"><a href="/jonyluyp/producten/auto-3/"><div id="auto3"></div></a></div>
  </section>
</div></div>

<!-- Afsluiten grid -->
<?php get_footer(); ?>
</div>
</div>
</div>


